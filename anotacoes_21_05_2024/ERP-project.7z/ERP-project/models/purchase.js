// ./models/purchase.js

const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const Purchase = sequelize.define('Purchase', {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        quantity: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        unitCost: {
            type: Sequelize.DECIMAL,
            allowNull: false
        },
        status: {
            type: Sequelize.ENUM('pending', 'completed', 'cancelled'),
            defaultValue: 'pending'
        }
        // parcelas
        // nota fiscal

        // criar tabela titulos a pagar
            // motivo
            // notafiscal
            // valor
            // número parcela
            // data vencimento
            // situação (aberto, pendente, liquidado)

            // movimentação produto
            // criação título
            // movimentação de título
                // id titulo
                // data movimentação
                // valor movimentação
                // valor multa
                // valor juros
                // tipo movimentação
                    // abertura
                    // pagamento

            // quando houver movimentação subtrari ou somar da tabela de títulos
    });

    Purchase.associate = (models) => {
        Purchase.belongsTo(models.Supplier, {
            foreignKey: 'supplierId',
            as: 'fornecedor'
        });
        Purchase.belongsTo(models.Quotation, {
            foreignKey: 'quotationId',
            as: 'cotacao'
        });
        Purchase.belongsTo(models.User, {
            foreignKey: 'buyerId',
            as: 'comprador'
        });
        Purchase.belongsTo(models.Product, {
            foreignKey: 'productId',
            as: 'produto'
        });
    };

    return Purchase;
};
