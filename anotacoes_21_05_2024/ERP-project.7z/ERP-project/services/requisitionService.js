// ./services/requisitionService.js

const db = require('../models');
const MovimentacaoProdutoService = require('./movimentacaoProdutoService');

class RequisitionService {
    constructor(requisitionModel) {
        this.Requisition = requisitionModel;
        this.movimentacaoProdutoService = new MovimentacaoProdutoService();
    }

    async createRequisition(requisitionData) {
        try {
            const hasStock = await this.movimentacaoProdutoService.checkStock(requisitionData.productId, requisitionData.quantity);
            
            if (hasStock) {
                const requisition = await this.Requisition.create({
                    ...requisitionData,
                    status: 'fulfilled'
                });

                // Atualizar o estoque do depósito
                await this.movimentacaoProdutoService.createMovimentacaoProduto({
                    depositoId: requisitionData.depositoId,
                    produtoId: requisitionData.productId,
                    tipoMovimento: 'Saida.Compra',
                    quantidade: requisitionData.quantity,
                    precoUnitario: 0,  // Ajuste conforme necessário
                    data: new Date()
                });

                return requisition;
            } else {
                const requisition = await this.Requisition.create(requisitionData);
                return requisition;
            }
        } catch (error) {
            throw error;
        }
    }

    async cancelRequisition(id) {
        try {
            const updatedRequisition = await this.Requisition.update(
                { status: 'cancelled' },
                { where: { id: id } }
            );
            return updatedRequisition;
        } catch (error) {
            throw error;
        }
    }

    async findAllRequisitions(page, pageSize) {
        try {
            const offset = (page - 1) * pageSize;
            const requisitions = await this.Requisition.findAndCountAll({
                limit: pageSize,
                offset: offset,
                include: [
                    { model: db.User, as: 'requerente' },
                    { model: db.Product, as: 'produto' },
                    { model: db.CostCenter, as: 'centroDeCusto' }
                ]
            });
            return requisitions;
        } catch (error) {
            throw error;
        }
    }

    async findRequisitionById(id) {
        try {
            const requisition = await this.Requisition.findByPk(id, {
                include: [
                    { model: db.User, as: 'requerente' },
                    { model: db.Product, as: 'produto' },
                    { model: db.CostCenter, as: 'centroDeCusto' }
                ]
            });
            return requisition;
        } catch (error) {
            throw error;
        }
    }

    async fulfillRequisition(id) {
        try {
            const requisition = await this.Requisition.findByPk(id);
            if (!requisition) {
                throw new Error('Requisition not found');
            }

            const hasStock = await this.movimentacaoProdutoService.checkStock(requisition.productId, requisition.quantity);
            if (hasStock) {
                await this.movimentacaoProdutoService.createMovimentacaoProduto({
                    depositoId: requisition.depositoId,
                    produtoId: requisition.productId,
                    tipoMovimento: 'Saida.Compra',
                    quantidade: requisition.quantity,
                    precoUnitario: 0, 
                    data: new Date()
                });

                await requisition.update({ status: 'fulfilled' });
                return requisition;
            } else {
                throw new Error('Insufficient stock');
            }
        } catch (error) {
            throw error;
        }
    }
}

module.exports = RequisitionService;
