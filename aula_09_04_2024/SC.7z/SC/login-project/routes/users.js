// ./routes/userRoutes.js

const express = require('express');
const db              = require("../models");
const userService     = require('../services/userService'); // Ajuste o caminho conforme necessário
const UserService     = new userService(db.User); // Ajuste o caminho conforme necessário

const userController  = require('../controllers/userController'); // Ajuste o caminho conforme necessário
const UserController   = new userController(UserService);

const router = express.Router();

router.get('/', function(req, res){res.send("USER OK")});

router.post('/create', function(req, res){UserController.create(req, res)});

module.exports = router;
