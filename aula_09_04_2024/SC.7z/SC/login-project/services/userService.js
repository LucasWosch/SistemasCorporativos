// ./services/userService.js

const bcrypt = require('bcryptjs');
const db = require('../models'); // Ajuste o caminho conforme necessário

class userService {
    // Construtor da classe recebendo a user model
    constructor (userModel){
        this.User = userModel;
    }

    async create(name, mail, password){
        try {
            const newUser = await this.User.create(
                {
                    name: name, 
                    mail: mail, 
                    password: bcrypt.encodeBase64(password)
                }
            );
            return newUser ? newUser: null;
        } catch (error) {
            throw error;
        }
    }
}

/*
const UserService = {
    createUser: async (userData) => {
        try {
            userData.password = bcrypt.hashSync(userData.password, bcrypt.genSaltSync(10));
            const user = await db.User.create(userData);
            return user;
        } catch (error) {
            throw error;
        }
    },

    getUserById: async (id) => {
        try {
            const user = await db.User.findByPk(id);
            return user;
        } catch (error) {
            throw error;
        }
    },

    updateUser: async (id, userData) => {
        try {
            if (userData.password) {
                userData.password = bcrypt.hashSync(userData.password, bcrypt.genSaltSync(10));
            }
            const user = await db.User.update(userData, {
                where: { id: id }
            });
            return user;
        } catch (error) {
            throw error;
        }
    },

    deleteUser: async (id) => {
        try {
            const user = await db.User.destroy({
                where: { id: id }
            });
            return user;
        } catch (error) {
            throw error;
        }
    }
};*/

module.exports = userService;

